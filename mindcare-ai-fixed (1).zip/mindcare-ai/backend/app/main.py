import asyncio
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import desc
from .config import FRONTEND_ORIGIN, GEMINI_API_KEY, GEMINI_MODEL, HF_ENABLED, HF_MODEL
from .database import Base, engine, get_db
from .models import ChatMessage, MoodEntry, JournalEntry
from .schemas import ChatRequest, ChatResponse, MoodRequest, JournalRequest
from .emotion import detect_emotion, fallback_emotion
from .safety import detect_crisis, CRISIS_REPLY
from .ai import generate_reply

Base.metadata.create_all(bind=engine)
app = FastAPI(title="MindCare AI API", version="1.0.1", description="RIO internship mental wellness chatbot demo")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_ORIGIN, "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"name": "MindCare AI API", "status": "running", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.get("/api/diagnostics")
def diagnostics():
    return {
        "api": "ok",
        "gemini_key_configured": bool(GEMINI_API_KEY and GEMINI_API_KEY != "replace_with_your_key"),
        "gemini_model": GEMINI_MODEL,
        "huggingface_enabled": HF_ENABLED,
        "huggingface_model": HF_MODEL,
        "note": "This endpoint does not verify external API credentials or download the Transformer model."
    }

@app.post("/api/chat", response_model=ChatResponse)
async def chat(payload: ChatRequest, db: Session = Depends(get_db)):
    message = payload.message.strip()
    if not message:
        raise HTTPException(status_code=422, detail="Message cannot be empty")

    crisis = detect_crisis(message)
    # The first Hugging Face call may download a large model. Fall back for this
    # message if the download/inference has not completed within 12 seconds.
    try:
        emotion, score = await asyncio.wait_for(
            asyncio.to_thread(detect_emotion, message), timeout=12.0
        )
    except asyncio.TimeoutError:
        print("[MindCare] Emotion model still loading; using fallback for this message.", flush=True)
        emotion, score = fallback_emotion(message)

    if crisis:
        reply = CRISIS_REPLY
    else:
        try:
            reply = await asyncio.wait_for(
                asyncio.to_thread(generate_reply, message, payload.history, emotion),
                timeout=30.0,
            )
        except asyncio.TimeoutError:
            print("[MindCare] Gemini timed out after 30 seconds.", flush=True)
            reply = ("I'm sorry, the AI service is taking too long to respond. Please try again. "
                     "You can still use the mood tracker and journal while the service is unavailable.")
        except Exception as exc:
            print(f"[MindCare] Gemini request failed: {exc}", flush=True)
            reply = ("I'm sorry, I couldn't reach the AI service just now. Please check the "
                     "Gemini API key, model access, and internet connection, then try again.")

    db.add(ChatMessage(session_id=payload.session_id, role="user", content=message, emotion=emotion))
    db.add(ChatMessage(session_id=payload.session_id, role="assistant", content=reply, emotion=emotion))
    db.commit()
    return ChatResponse(reply=reply, emotion=emotion, emotion_score=round(score, 4), crisis=crisis,
                        safety_message="Crisis support pathway activated" if crisis else None)

@app.get("/api/chat/{session_id}")
def get_chat(session_id: str, db: Session = Depends(get_db)):
    rows = db.query(ChatMessage).filter(ChatMessage.session_id == session_id).order_by(ChatMessage.id).all()
    return [{"id": r.id, "role": r.role, "content": r.content, "emotion": r.emotion,
             "created_at": r.created_at.isoformat()} for r in rows]

@app.post("/api/mood")
def add_mood(payload: MoodRequest, db: Session = Depends(get_db)):
    entry = MoodEntry(mood=payload.mood, note=payload.note)
    db.add(entry); db.commit(); db.refresh(entry)
    return {"id": entry.id, "mood": entry.mood, "note": entry.note, "created_at": entry.created_at.isoformat()}

@app.get("/api/mood")
def list_moods(db: Session = Depends(get_db)):
    rows = db.query(MoodEntry).order_by(desc(MoodEntry.created_at)).limit(30).all()
    return [{"id": r.id, "mood": r.mood, "note": r.note, "created_at": r.created_at.isoformat()} for r in rows]

@app.post("/api/journal")
def add_journal(payload: JournalRequest, db: Session = Depends(get_db)):
    entry = JournalEntry(title=payload.title, content=payload.content)
    db.add(entry); db.commit(); db.refresh(entry)
    return {"id": entry.id, "title": entry.title, "content": entry.content, "created_at": entry.created_at.isoformat()}

@app.get("/api/journal")
def list_journal(db: Session = Depends(get_db)):
    rows = db.query(JournalEntry).order_by(desc(JournalEntry.created_at)).limit(30).all()
    return [{"id": r.id, "title": r.title, "content": r.content, "created_at": r.created_at.isoformat()} for r in rows]
