import os
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
HF_ENABLED = os.getenv("HF_ENABLED", "true").lower() == "true"
HF_MODEL = os.getenv("HF_MODEL", "j-hartmann/emotion-english-distilroberta-base")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./mindcare.db")
FRONTEND_ORIGIN = os.getenv("FRONTEND_ORIGIN", "http://localhost:5173")
