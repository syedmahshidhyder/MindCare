from pydantic import BaseModel, Field
from typing import Literal

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    session_id: str = Field(min_length=1, max_length=80)
    history: list[dict] = Field(default_factory=list, max_length=12)

class ChatResponse(BaseModel):
    reply: str
    emotion: str
    emotion_score: float
    crisis: bool
    safety_message: str | None = None

class MoodRequest(BaseModel):
    mood: Literal["great", "good", "okay", "low", "anxious", "stressed"]
    note: str = Field(default="", max_length=500)

class JournalRequest(BaseModel):
    title: str = Field(default="My reflection", max_length=120)
    content: str = Field(min_length=1, max_length=10000)
