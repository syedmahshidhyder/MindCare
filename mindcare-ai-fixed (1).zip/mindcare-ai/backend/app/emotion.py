from functools import lru_cache
from .config import HF_ENABLED, HF_MODEL

@lru_cache(maxsize=1)
def _load_classifier():
    print(f"[MindCare] Loading Hugging Face model: {HF_MODEL}", flush=True)
    from transformers import pipeline
    model = pipeline("text-classification", model=HF_MODEL, top_k=None, truncation=True)
    print("[MindCare] Hugging Face emotion model loaded.", flush=True)
    return model

def fallback_emotion(text: str) -> tuple[str, float]:
    """Fast keyword fallback used if the Transformer is disabled or still downloading."""
    lower = text.lower()
    rules = {
        "sadness": ["sad", "lonely", "hopeless", "cry", "empty", "down", "unhappy"],
        "fear": ["scared", "afraid", "panic", "worried", "anxious", "nervous"],
        "anger": ["angry", "furious", "annoyed", "hate", "frustrated"],
        "joy": ["happy", "excited", "grateful", "great", "wonderful", "good"],
        "disgust": ["disgusted", "gross", "revolting"],
        "surprise": ["surprised", "shocked", "unexpected"],
    }
    for label, words in rules.items():
        if any(word in lower for word in words):
            return label, 0.50
    return "neutral", 0.50

def detect_emotion(text: str) -> tuple[str, float]:
    """Return a best-effort emotion label and score. Not a diagnosis."""
    if HF_ENABLED:
        try:
            raw = _load_classifier()(text[:1500])
            predictions = raw[0] if raw and isinstance(raw[0], list) else raw
            best = max(predictions, key=lambda item: float(item["score"]))
            return str(best["label"]).lower(), float(best["score"])
        except Exception as exc:
            print(f"[MindCare] Hugging Face unavailable; using fallback: {exc}", flush=True)
    return fallback_emotion(text)
