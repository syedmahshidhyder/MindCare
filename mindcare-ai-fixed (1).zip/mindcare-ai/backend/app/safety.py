import re

# Conservative demo screening only. This is NOT a validated suicide-risk classifier.
CRISIS_PATTERNS = [
    r"\b(kill myself|end my life|suicide|suicidal|want to die|don't want to live|do not want to live)\b",
    r"\b(hurt myself|harm myself|self[- ]harm|cut myself)\b",
]

def detect_crisis(text: str) -> bool:
    return any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in CRISIS_PATTERNS)

CRISIS_REPLY = (
    "I'm really sorry you're facing this. I can't assess your immediate safety, but I want you "
    "to get support from a real person now. If you may act on these thoughts or are in immediate "
    "danger, call your local emergency number or go to the nearest emergency department. In India, "
    "you can call 112 for emergency assistance. If possible, move near someone you trust, tell them "
    "plainly that you may not be safe alone, and move away from anything you could use to hurt yourself. "
    "Would you be able to contact someone you trust right now?"
)
