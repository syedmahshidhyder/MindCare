from app.safety import detect_crisis

def test_detects_explicit_crisis_language():
    assert detect_crisis("I want to end my life") is True

def test_does_not_flag_ordinary_stress():
    assert detect_crisis("I am stressed about my exams") is False
