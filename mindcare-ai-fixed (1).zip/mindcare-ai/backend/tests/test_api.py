import os
os.environ["HF_ENABLED"] = "false"
os.environ["GEMINI_API_KEY"] = ""
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/api/health").json()["status"] == "ok"

def test_crisis_path_does_not_call_gemini():
    response = client.post("/api/chat", json={"message": "I want to end my life", "session_id": "test-session"})
    assert response.status_code == 200
    assert response.json()["crisis"] is True
    assert "112" in response.json()["reply"]

def test_mood_create_and_list():
    response = client.post("/api/mood", json={"mood": "okay", "note": "test note"})
    assert response.status_code == 200
    assert response.json()["mood"] == "okay"
