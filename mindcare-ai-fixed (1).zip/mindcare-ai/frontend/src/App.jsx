import React, { useEffect, useRef, useState } from 'react';
import { Activity, BookHeart, Brain, CalendarDays, Heart, Home, MessageCircle, Send, ShieldCheck, Sparkles, Smile, Wind } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';
const SESSION_ID = (() => {
  let id = sessionStorage.getItem('mindcare_session');
  if (!id) { id = crypto.randomUUID(); sessionStorage.setItem('mindcare_session', id); }
  return id;
})();

export default function App() {
  const [page, setPage] = useState('chat');
  const [messages, setMessages] = useState([{ role: 'assistant', content: "Hello, I'm MindCare AI. I'm here to listen and support your everyday wellbeing. What's on your mind today?" }]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [emotion, setEmotion] = useState('Not detected yet');
  const [moods, setMoods] = useState([]);
  const [journals, setJournals] = useState([]);
  const [mood, setMood] = useState('okay');
  const [moodNote, setMoodNote] = useState('');
  const [journalTitle, setJournalTitle] = useState('My reflection');
  const [journalContent, setJournalContent] = useState('');
  const [notice, setNotice] = useState('');
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, busy]);
  useEffect(() => { loadMood(); loadJournal(); }, []);

  async function request(path, options = {}) {
    const response = await fetch(`${API}${path}`, { headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(40000), ...options });
    if (!response.ok) throw new Error(`Server returned ${response.status}`);
    return response.json();
  }

  async function loadMood() { try { setMoods(await request('/api/mood')); } catch { /* backend may still be starting */ } }
  async function loadJournal() { try { setJournals(await request('/api/journal')); } catch { /* backend may still be starting */ } }

  async function sendMessage(e) {
    e?.preventDefault();
    const text = input.trim();
    if (!text || busy) return;
    const next = [...messages, { role: 'user', content: text }];
    setMessages(next); setInput(''); setBusy(true); setNotice('');
    try {
      const data = await request('/api/chat', { method: 'POST', body: JSON.stringify({ message: text, session_id: SESSION_ID, history: next.slice(0, -1).slice(-10) }) });
      setMessages(current => [...current, { role: 'assistant', content: data.reply, crisis: data.crisis }]);
      setEmotion(`${data.emotion} · ${Math.round(data.emotion_score * 100)}% model score`);
    } catch (err) {
      const message = err.name === 'TimeoutError' ? 'The request took too long. Check the backend terminal and Gemini API connection, then try again.' : 'I could not connect to the backend. Please check that FastAPI is running at 127.0.0.1:8000.';
      setMessages(current => [...current, { role: 'assistant', content: message }]);
      setNotice(`${message} (${err.message})`);
    } finally { setBusy(false); }
  }

  async function saveMood(e) {
    e.preventDefault();
    try { await request('/api/mood', { method: 'POST', body: JSON.stringify({ mood, note: moodNote }) }); setMoodNote(''); setNotice('Mood check-in saved.'); await loadMood(); }
    catch { setNotice('Could not save mood. Check that the backend is running.'); }
  }

  async function saveJournal(e) {
    e.preventDefault();
    if (!journalContent.trim()) return;
    try { await request('/api/journal', { method: 'POST', body: JSON.stringify({ title: journalTitle, content: journalContent }) }); setJournalContent(''); setNotice('Journal entry saved.'); await loadJournal(); }
    catch { setNotice('Could not save journal entry. Check that the backend is running.'); }
  }

  const nav = [ ['chat', MessageCircle, 'AI Companion'], ['mood', Activity, 'Mood tracker'], ['journal', BookHeart, 'Journal'], ['about', ShieldCheck, 'About & safety'] ];
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><Brain size={23}/></div><div><b>MindCare</b><span>AI WELLNESS COMPANION</span></div></div>
      <div className="nav-label">WORKSPACE</div>
      <nav>{nav.map(([id, Icon, label]) => <button key={id} className={`nav-item ${page === id ? 'active' : ''}`} onClick={() => { setPage(id); setNotice(''); }}><Icon size={18}/>{label}</button>)}</nav>
      <div className="sidebar-bottom"><div className="privacy-card"><ShieldCheck size={18}/><b>Your wellbeing matters</b><p>This demo is not a medical service. Avoid entering identifying or highly sensitive information.</p></div><div className="profile"><div className="avatar">M</div><div><b>Guest user</b><span>Personal space</span></div></div></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div><span className="eyebrow">YOUR PERSONAL WELLNESS SPACE</span><h1>{page === 'chat' ? 'AI Companion' : page === 'mood' ? 'Mood tracker' : page === 'journal' ? 'Private journal' : 'About MindCare'}</h1></div><div className="top-status"><span className="status-dot"/> Supportive space</div></header>
      {notice && <div className="notice">{notice}</div>}
      {page === 'chat' && <section className="chat-layout">
        <div className="chat-card"><div className="chat-heading"><div className="bot-avatar"><Sparkles size={21}/></div><div><b>MindCare AI</b><span><i className="status-dot"/> Here to listen</span></div><div className="secure-label"><ShieldCheck size={14}/> AI support</div></div>
          <div className="message-list">{messages.map((m, i) => <div key={i} className={`message-row ${m.role}`}><div className="message-avatar">{m.role === 'assistant' ? <Brain size={16}/> : 'Y'}</div><div className={`bubble ${m.crisis ? 'crisis-bubble' : ''}`}><span className="sender">{m.role === 'assistant' ? 'MindCare AI' : 'You'}</span><p>{m.content}</p></div></div>)}{busy && <div className="message-row assistant"><div className="message-avatar"><Brain size={16}/></div><div className="bubble typing">Thinking gently<span> • • •</span></div></div>}<div ref={endRef}/></div>
          <form className="composer" onSubmit={sendMessage}><input value={input} onChange={e => setInput(e.target.value)} placeholder="Share what's on your mind..." maxLength={4000}/><button disabled={!input.trim() || busy} aria-label="Send message"><Send size={18}/></button></form><p className="chat-disclaimer">MindCare AI offers general wellbeing support, not diagnosis or treatment.</p>
        </div>
        <div className="right-rail"><div className="rail-card welcome-card"><div className="sun-icon"><Heart size={20}/></div><span className="eyebrow">A GENTLE REMINDER</span><h3>You don't have to figure everything out at once.</h3><p>Small steps count. Take a moment, breathe, and be kind to yourself.</p></div><div className="rail-card"><div className="rail-title"><Brain size={17}/><b>Emotion signal</b></div><p className="muted">Hugging Face model estimate</p><div className="emotion-value">{emotion}</div><p className="tiny-note">This is an uncertain language-model estimate, not a diagnosis or clinical assessment.</p></div><div className="rail-card exercise-card"><div className="rail-title"><Wind size={17}/><b>Quick reset</b></div><h3>Try paced breathing</h3><p>Inhale gently for 4 seconds, then exhale for 6 seconds. Repeat comfortably without forcing your breath.</p></div></div>
      </section>}
      {page === 'mood' && <section className="content-grid"><div className="panel"><div className="section-icon"><Smile/></div><h2>How are you feeling today?</h2><p className="muted">A quick check-in can help you notice patterns over time.</p><form onSubmit={saveMood}><label className="field-label">Choose the closest match</label><div className="mood-options">{[['great','😄','Great'],['good','🙂','Good'],['okay','😐','Okay'],['low','😔','Low'],['anxious','😟','Anxious'],['stressed','😣','Stressed']].map(([v, emoji, label]) => <button type="button" key={v} onClick={() => setMood(v)} className={`mood-option ${mood === v ? 'selected' : ''}`}><span>{emoji}</span>{label}</button>)}</div><label className="field-label" htmlFor="mood-note">Anything you'd like to note? (optional)</label><textarea id="mood-note" value={moodNote} onChange={e => setMoodNote(e.target.value)} placeholder="What might be influencing your mood?" maxLength={500}/><button className="primary-btn">Save check-in</button></form></div><div className="panel"><h2>Recent check-ins</h2><p className="muted">Your latest saved mood entries.</p>{moods.length ? <div className="entry-list">{moods.map(m => <div className="entry" key={m.id}><div className="entry-emoji">{({great:'😄',good:'🙂',okay:'😐',low:'😔',anxious:'😟',stressed:'😣'})[m.mood]}</div><div><b>{m.mood[0].toUpperCase()+m.mood.slice(1)}</b><span>{m.note || 'No note added'}</span><small>{new Date(m.created_at).toLocaleString()}</small></div></div>)}</div> : <div className="empty-state"><CalendarDays/><p>No check-ins yet. Add your first mood above.</p></div>}</div></section>}
      {page === 'journal' && <section className="content-grid"><div className="panel"><div className="section-icon"><BookHeart/></div><h2>Write what's on your mind</h2><p className="muted">Use this space for personal reflection. Keep identifying details out of this demo.</p><form onSubmit={saveJournal}><label className="field-label" htmlFor="journal-title">Entry title</label><input id="journal-title" value={journalTitle} onChange={e => setJournalTitle(e.target.value)} maxLength={120}/><label className="field-label" htmlFor="journal-content">Your reflection</label><textarea className="journal-area" id="journal-content" value={journalContent} onChange={e => setJournalContent(e.target.value)} placeholder="Today, I'm feeling..." maxLength={10000}/><button className="primary-btn" disabled={!journalContent.trim()}>Save journal entry</button></form></div><div className="panel"><h2>Past reflections</h2><p className="muted">Your latest saved entries.</p>{journals.length ? <div className="entry-list">{journals.map(j => <div className="journal-entry" key={j.id}><b>{j.title}</b><p>{j.content}</p><small>{new Date(j.created_at).toLocaleString()}</small></div>)}</div> : <div className="empty-state"><BookHeart/><p>Your reflections will appear here.</p></div>}</div></section>}
      {page === 'about' && <section className="panel about-panel"><div className="section-icon"><ShieldCheck/></div><h2>Support with clear boundaries</h2><p>MindCare AI is an educational RIO internship prototype for general emotional-wellbeing support. It is not a medical device, therapist, diagnostic tool, or emergency service.</p><div className="safety-list"><div><ShieldCheck/><span><b>No diagnosis</b><small>Emotion labels are approximate model outputs and cannot identify a mental-health condition.</small></span></div><div><Heart/><span><b>Human support matters</b><small>For ongoing distress, contact a qualified mental-health professional or someone you trust.</small></span></div><div><Activity/><span><b>Emergency support</b><small>If you may be in immediate danger, call your local emergency number or go to an emergency department. In India, emergency assistance is available at 112.</small></span></div></div><p className="warning-note">Demo privacy notice: this starter stores mood entries, journal entries, and chat messages in a local SQLite database without user authentication or encryption. Use fictional test data only until proper access controls, encryption, retention and deletion policies, and security review are implemented.</p></section>}
      <footer className="footer">MindCare AI <span>•</span> Built for learning and wellbeing research <span>•</span> Not a substitute for professional care</footer>
    </main>
  </div>;
}
